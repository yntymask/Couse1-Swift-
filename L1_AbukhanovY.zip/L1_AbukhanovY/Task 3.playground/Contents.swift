import Foundation

//user input data

let initialMoney: Double = 1000 // inital deposit amount, in $
let interestRate: Double = 15 // annual interest rate
let period: Double = 5 // in years

// use compound interest formula A = P * (1+r)^t
var finalSum = initialMoney * pow((1+interestRate/100), period)
