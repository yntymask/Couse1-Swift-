import Foundation

// standard quadratic equiation is ax2+bx+c=0

// a,b,c are the coefficients.
let a: Double = 1
let b: Double = 40
let c: Double = 10

//lets declare the root of equation as an array
var root = [Double]()

//to calculate the discriminant
var discriminant = pow(b, 2) - 4*a*c

if (a != 0) && (discriminant >= 0) {
    //Equation might have 3 cases: 2 roots, 1 root, no roots
    if discriminant > 0 {
        root.append((-b+sqrt(discriminant))/(2*a))
        root.append((-b-sqrt(discriminant))/(2*a))
        print("Two roots exist \(root)")
    }

    else {
        root.append(-b/(2*a))
        print("One root exists: \(root)")
    }
}
else {
    print("no roots available for a given coefficients")
}
