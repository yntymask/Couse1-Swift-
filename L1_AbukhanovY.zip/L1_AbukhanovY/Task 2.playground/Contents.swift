import Foundation

// Declare sides of the triangle. Since pow and sqrt functions return Double, all input variables will be double either
let a: Double = 10
let b: Double = 20

//Declare the perimeter, area, hypotenuse
var S: Double = 0
var P: Double = 0
var c: Double = 0

c = round(sqrt(pow(b, 2) + pow(a, 2)))
P = round(a + b + c)
S = 0.5*a*b
